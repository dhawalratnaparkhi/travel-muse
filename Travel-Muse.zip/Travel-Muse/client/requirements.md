## Packages
framer-motion | Smooth page transitions and scroll animations
date-fns | formatting dates for tours
react-day-picker | Date picker component for forms

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Playfair Display', serif"],
  body: ["'Lato', sans-serif"],
}
